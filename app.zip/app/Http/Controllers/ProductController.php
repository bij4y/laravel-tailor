<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::all();
        return view('backend.products.index',compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        return view('backend.products.create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'SKU' => 'required',
            'name' => 'required',
            'price' => 'required',
            'sp' => 'required',
            'feature' => 'required',


        ]);
        $product = new Product();
        $product->SKU = $request->SKU;
        $product->name = $request->name;
        $product->price = $request->price;
        $product->discount = $request->discount;
        $product->sp = $request->sp;
        if($request->hasFile('feature')){
            $file = $request->feature;
            $newName = time() . $file->getClientOriginalName();
            $file->move('feature',$newName);
            $product->feature = 'feature/' . $newName;

        }
        $product->category_id = $request->category_id;
        $product->description = $request->description;
        $product->save();
        if($request->hasFile('images')){
            foreach($request->images as $image){
                $productImage = new ProductImage();
                $newName = time() . $image->getClientOriginalName();
                $image->move('images',$newName);
                $productImage->name = 'images/' . $newName;
                $productImage->product_id = $product->id;
                $productImage->save();
            }

        }
        $request->session()->flash('alert-success', 'User was successful added!');
        return redirect()->back();

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories = Category::all();
        $product = Product::find($id);
        return view('backend.products.edit',compact('product','categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $product = Product::find($id);
        $product->SKU = $request->SKU;
        $product->name = $request->name;
        $product->price = $request->price;
        $product->discount = $request->discount;
        $product->sp = $request->sp;
        if($request->hasFile('feature')){
            $file = $request->feature;
            $newName = time() . $file->getClientOriginalName();
            $file->move('feature',$newName);
            $product->feature = 'feature/' . $newName;

        }
        $product->category_id = $request->category_id;
        $product->description = $request->description;
        $product->update();
        if($request->hasFile('images')){
            foreach($request->images as $image){
                $productImage = ProductImage::find($id) ;
                $newName = time() . $image->getClientOriginalName();
                $image->move('images',$newName);
                $productImage->name = 'images/' . $newName;
                $productImage->product_id = $product->id;
                $productImage->update();
            }

        }
        $request->session()->flash('alert-success', 'Editing was successful ');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
